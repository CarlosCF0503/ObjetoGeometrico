/**
 * 
 */
/**
 * 
 */
module ObjetoGeometrico {
}